let nombre = prompt('Ingrese Su Nombre');
let apellido = prompt('Ingresu Su Apellido');
console.log('Hola ' + nombre+apellido);
 