let edadUsuario = prompt('Ingresu Su edad');
if (edadUsuario >= 18){
let nombre = prompt('Ingrese Su Nombre');
let apellido = prompt('Ingrese Su Apellido');
console.log('Hola ' +nombre+" "+apellido);
}else { 
        alert("DEBE SER MAYOR DE EDAD PARA ENTRAR A LA WEB")
};
